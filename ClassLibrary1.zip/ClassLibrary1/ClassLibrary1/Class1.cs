﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Class1
{
    public int add(int a, int b)
    {
        return a + b;
    }

    public int minus(int a, int b)
    {
        return a - b;
}

    public int ass(int a, int b)
{
    return a / b;
}

    public int umnojit(int a, int b)
{
    return a * b;
}
}
